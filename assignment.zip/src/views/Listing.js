import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";

export default function Listing() {
  return (
    <Container>
      <Row className="pt-5 mb-2">
        <Col className="text-center">
            <h1>Office Transactions</h1>
        </Col>
      </Row>
      <Row className="py-2">
        <Col className="text-end">
            <Link to="/add-transaction">
                <Button variant="dark">+ Add Transaction</Button>
            </Link>
        </Col>
      </Row>
      <Row>
        <Col>
        <Table striped bordered hover>
            <thead >
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Credit</th>
                    <th>Debit</th>
                    <th>Running Balance</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                </tr>
            </tbody>
            </Table>
        </Col>
      </Row>
    </Container>
  );
}
