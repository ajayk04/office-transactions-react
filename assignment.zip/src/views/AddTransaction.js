import { useState } from 'react';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

import Form from "react-bootstrap/Form";

import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";

export default function AddTransaction() {

    const [transaction, setTransaction] = useState({
        type: "",
        amount: 0,
        description: ""
    });


    const addNewTransaction = (event) => {
        console.log(transaction);

        event.preventDefault();
        event.stopPropagation();
    };

    return (
        <Container>
            <Row className="pt-5 mb-2">
                <Col className="text-center">
                    <h1>New Transactions</h1>
                </Col>
            </Row>
            <Row className="py-2">
                <Col className="text-end">
                    <Link to="/">
                        <Button variant="primary">Back</Button>
                    </Link>
                </Col>
            </Row>
            <Row>
                <Col className="border border-1 p-5 rounded-3">
                    <Form onSubmit={(e) => {addNewTransaction(e)}}>
                        <Form.Group as={Row} className="mb-3" controlId="type">
                            <Form.Label column sm="2">
                                Transaction Type
                            </Form.Label>
                            <Col sm="10">
                                <Form.Select
                                    aria-label="Default select example"
                                    onChange={(e) => { setTransaction({ ...transaction, type: e.target.value }) }}
                                >
                                    <option value="credit">Credit</option>
                                    <option value="debit">Debit</option>
                                </Form.Select>
                            </Col>
                        </Form.Group>

                        <Form.Group as={Row} className="mb-3" controlId="amount">
                            <Form.Label column sm="2">
                                Amount
                            </Form.Label>
                            <Col sm="10">
                                <Form.Control
                                    type="text"
                                    placeholder="Amount"
                                    onChange={(e) => { setTransaction({ ...transaction, amount: e.target.value }) }}
                                />
                            </Col>
                        </Form.Group>

                        <Form.Group as={Row} className="mb-3" controlId="description">
                            <Form.Label column sm="2">
                                Description
                            </Form.Label>
                            <Col sm="10">
                                <Form.Control
                                    as="textarea"
                                    rows={3}
                                    onChange={(e) => { setTransaction({ ...transaction, description: e.target.value }) }}
                                />
                            </Col>
                        </Form.Group>

                        <Form.Group as={Row} className="mb-3" controlId="button">
                            <Col className="text-end">
                                <Button type="submit" variant="primary">Save</Button>
                            </Col>
                        </Form.Group>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
}
